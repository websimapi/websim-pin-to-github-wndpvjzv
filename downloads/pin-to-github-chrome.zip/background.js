(() => {
  const api = globalThis.browser || globalThis.chrome;
  const GH_API = 'https://api.github.com';
  const WS_API = 'https://websim.com/api/v1';
  const defaults = {
    enabled: true, token: '', owner: '', branchMode: 'main', customBranch: '',
    visibility: 'private', lastEvents: [], syncedVersions: {}, projectMap: {}, debugLogs: [], advancedLogs: false
  };

  const storageGet = (keys) => new Promise((resolve) => api.storage.local.get(keys, resolve));
  const storageSet = (value) => new Promise((resolve) => api.storage.local.set(value, resolve));
  let logQueue = Promise.resolve();
  const trackedWebsimRequests = new Map();
  const syncInFlight = new Set();

  function debugLog(event, detail = {}) {
    const entry = { at: new Date().toISOString(), event, ...detail };
    logQueue = logQueue.then(async () => {
      const stored = await storageGet({ debugLogs: [] });
      await storageSet({ debugLogs: [...(stored.debugLogs || []), entry].slice(-160) });
    }).catch(() => {});
    return logQueue;
  }

  function safeDebugDetail(detail = {}) {
    return Object.fromEntries(Object.entries(detail).slice(0, 24).map(([key, value]) => {
      if (typeof value === 'string') return [key, value.replace(/([?&](?:token|access_token|authorization|code|key)=)[^&]*/gi, '$1[redacted]').slice(0, 400)];
      if (typeof value === 'number' || typeof value === 'boolean' || value === null) return [key, value];
      return [key, String(value).slice(0, 400)];
    }));
  }

  function websimNetworkUrl(value) {
    try {
      const url = new URL(value);
      if (!/(^|\.)websim\.com$/i.test(url.hostname)) return null;
      if (!/\/api\//i.test(url.pathname) && !/(pin|pinned|bookmark|collection|save)/i.test(url.pathname)) return null;
      return `${url.origin}${url.pathname}`;
    } catch {
      return null;
    }
  }

  function projectMutation(value) {
    try {
      const url = new URL(value);
      const match = url.pathname.match(/\/api\/v1\/projects\/([^/]+)$/i);
      return match ? { projectId: decodeURIComponent(match[1]) } : null;
    } catch {
      return null;
    }
  }

  function decodeRequestBytes(bytes) {
    try {
      if (!bytes) return '';
      if (Array.isArray(bytes)) return new TextDecoder().decode(new Uint8Array(bytes));
      return new TextDecoder().decode(bytes);
    } catch {
      return '';
    }
  }

  function requestFieldEntries(value, prefix = '', depth = 0) {
    if (!value || typeof value !== 'object' || depth > 3) return [];
    return Object.entries(value).flatMap(([key, child]) => {
      const path = prefix ? `${prefix}.${key}` : key;
      if (child && typeof child === 'object') {
        if (Array.isArray(child)) return [[path, `[${child.length} items]`]];
        return requestFieldEntries(child, path, depth + 1);
      }
      return [[path, child]];
    });
  }

  function requestBodySummary(body) {
    if (!body) return { kind: null, keys: [], versionFields: {} };
    let parsed = body.formData || null;
    if (!parsed && body.raw?.length) {
      for (const part of body.raw) {
        const text = decodeRequestBytes(part.bytes);
        if (!text) continue;
        try {
          parsed = JSON.parse(text);
          break;
        } catch {
          try {
            const params = new URLSearchParams(text);
            if ([...params.keys()].length) {
              parsed = Object.fromEntries(params.entries());
              break;
            }
          } catch {}
        }
      }
    }
    if (!parsed || typeof parsed !== 'object') return { kind: 'raw', keys: [], versionFields: {} };
    const entries = requestFieldEntries(parsed);
    const versionFields = Object.fromEntries(entries
      .filter(([key]) => /pin|version|revision/i.test(key))
      .slice(0, 24)
      .map(([key, value]) => [key, typeof value === 'string' ? value.slice(0, 80) : value]));
    return {
      kind: body.formData ? 'formData' : 'json',
      keys: entries.map(([key]) => key).slice(0, 40),
      versionFields
    };
  }

  function mutationStateEntries(value, prefix = '', depth = 0) {
    if (!value || typeof value !== 'object' || depth > 3) return [];
    return Object.entries(value).flatMap(([key, child]) => {
      const path = prefix ? `${prefix}.${key}` : key;
      if (/pin|bookmark|version|revision/i.test(key)) return [[path, child]];
      if (child && typeof child === 'object' && !Array.isArray(child)) {
        return mutationStateEntries(child, path, depth + 1);
      }
      return [];
    });
  }

  function projectMutationState(data) {
    const project = data?.project || data?.site || data || {};
    const revision = data?.project_revision || data?.revision || {};
    const fields = Object.fromEntries(
      [...mutationStateEntries(project), ...mutationStateEntries(revision)]
        .sort(([a], [b]) => a.localeCompare(b))
    );
    return {
      version: project.current_version ?? project.currentVersion ?? revision.version ?? revision.revision_number ?? null,
      fingerprint: JSON.stringify(fields)
    };
  }

  async function readProjectMutationState(projectId) {
    try {
      return projectMutationState(await wsJson(`/projects/${encodeURIComponent(projectId)}`));
    } catch {
      return null;
    }
  }

  function knownSyncedVersion(settings, projectId) {
    const mapped = settings.projectMap?.[projectId];
    if (!mapped?.repo) return null;
    const branch = mapped.branch || branchName(settings, {});
    const versions = settings.syncedVersions || {};
    const directKey = `${settings.owner || ''}/${mapped.repo}:${projectId}:${branch}`;
    if (versions[directKey] !== undefined && versions[directKey] !== null) return versions[directKey];
    const suffix = `/${mapped.repo}:${projectId}:${branch}`;
    const matchingKey = Object.keys(versions).find((key) => key.endsWith(suffix));
    return matchingKey ? versions[matchingKey] : null;
  }

  function setSyncIndicator(active) {
    const action = api.action || api.browserAction;
    if (!action) return;
    Promise.resolve(action.setBadgeText?.({ text: active ? '…' : '' })).catch(() => {});
    Promise.resolve(action.setBadgeBackgroundColor?.({ color: active ? '#d9ee65' : '#11131a' })).catch(() => {});
    Promise.resolve(action.setTitle?.({ title: active ? 'Pin to GitHub · syncing…' : 'Pin to GitHub' })).catch(() => {});
  }

  async function config() {
    const stored = await storageGet(defaults);
    return { ...defaults, ...stored };
  }

  async function jsonRequest(url, options = {}) {
    const response = await fetch(url, { ...options, headers: {
      Accept: 'application/vnd.github+json',
      ...(options.headers || {})
    }});
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.message || `Request failed (${response.status})`);
      error.status = response.status;
      error.url = url;
      throw error;
    }
    return data;
  }

  async function wsJson(path) {
    await debugLog('websim.request', { method: 'GET', path });
    try {
      const response = await fetch(`${WS_API}${path}`, {
        credentials: 'include',
        headers: { Accept: 'application/json', 'Accept-Language': 'en-US,en;q=0.9' }
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const error = new Error(data?.error?.message || data?.error || `Websim request failed (${response.status})`);
        error.status = response.status;
        throw error;
      }
      await debugLog('websim.response', { method: 'GET', path, status: response.status });
      return data;
    } catch (error) {
      await debugLog('websim.error', { method: 'GET', path, status: error.status || null, message: error.message });
      throw error;
    }
  }

  function unwrap(data, key) {
    if (data?.[key]?.data) return data[key].data;
    if (Array.isArray(data?.[key])) return data[key];
    if (Array.isArray(data?.data)) return data.data;
    return [];
  }

  function normalizedRevision(item) {
    return item?.project_revision || item?.revision || item;
  }

  function projectIdFromWebsimUrl(value) {
    if (!value) return null;
    try {
      const url = new URL(value);
      const route = url.pathname.match(/\/([cp])\/([a-zA-Z0-9_-]+)/);
      if (route) return route[2];
      const host = url.hostname.match(/^([a-zA-Z0-9_-]+)\.c\.websim\.com$/i);
      return host ? host[1] : null;
    } catch {
      return null;
    }
  }

  async function resolveProjectId(payload) {
    if (payload?.projectId) return payload.projectId;
    const directProjectId = projectIdFromWebsimUrl(payload?.url);
    if (directProjectId) return directProjectId;
    try {
      const route = new URL(payload?.url || '');
      const match = route.pathname.match(/^\/@([^/]+)\/([^/]+)/);
      if (!match) return null;
      const response = await wsJson(`/users/${encodeURIComponent(match[1])}/projects?first=100`);
      const projects = unwrap(response, 'projects').map((item) => item?.project || item).filter(Boolean);
      const slug = decodeURIComponent(match[2]).toLowerCase();
      const found = projects.find((project) => String(project.slug || '').toLowerCase() === slug) ||
        projects.find((project) => String(project.title || '').toLowerCase() === String(payload.title || '').toLowerCase());
      return found?.id || null;
    } catch {
      return null;
    }
  }

  async function currentRevision(projectId) {
    let project = {};
    try { project = await wsJson(`/projects/${encodeURIComponent(projectId)}`); } catch {}
    const projectData = project.project || project.site || project;
    const direct = projectData.current_revision || projectData.currentRevision || projectData.revision;
    const directVersion = projectData.current_version ?? projectData.currentVersion ?? direct?.version;
    if (directVersion !== undefined && directVersion !== null) {
      return { version: directVersion, revision: normalizedRevision(direct || { version: directVersion }) };
    }
    const revisionsResponse = await wsJson(`/projects/${encodeURIComponent(projectId)}/revisions?first=50`);
    const revisions = unwrap(revisionsResponse, 'revisions').map(normalizedRevision).filter(Boolean);
    revisions.sort((a, b) => Number(a.version ?? a.revision_number ?? 0) - Number(b.version ?? b.revision_number ?? 0));
    const revision = revisions[revisions.length - 1];
    if (!revision) throw new Error('No Websim revision was found for this project');
    return { version: revision.version ?? revision.revision_number, revision };
  }

  async function revisionFiles(projectId, version, revision) {
    const files = {};
    let html = revision.html || (typeof revision.content === 'string' ? revision.content : null) || revision.source || null;
    const cdnBase = `https://${projectId}.c.websim.com`;
    if (!html) {
      const htmlResponse = await fetch(`${cdnBase}/index.html?v=${encodeURIComponent(version)}`);
      if (htmlResponse.ok) html = await htmlResponse.text();
    }
    if (html) files['index.html'] = new TextEncoder().encode(html);

    let assets = [];
    try {
      assets = unwrap(await wsJson(`/projects/${encodeURIComponent(projectId)}/revisions/${encodeURIComponent(version)}/assets`), 'assets');
    } catch {}
    const selected = assets.filter((asset) => asset?.path && asset.path !== 'index.html').slice(0, 80);
    await Promise.all(selected.map(async (asset) => {
      const path = String(asset.path).replace(/^[/\\.]+/, '');
      if (typeof asset.content === 'string' && asset.content) {
        files[path] = new TextEncoder().encode(asset.content);
        return;
      }
      try {
        const response = await fetch(`${cdnBase}/${path.split('/').map(encodeURIComponent).join('/')}?v=${encodeURIComponent(version)}`);
        if (response.ok) files[path] = new Uint8Array(await response.arrayBuffer());
      } catch {}
    }));
    if (!Object.keys(files).length) throw new Error('The revision did not expose any files');
    return files;
  }

  function toBase64(bytes) {
    let binary = '';
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    return btoa(binary);
  }

  function repoPath(owner, repo) {
    return `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`;
  }

  function generatedRepoName(projectId, title) {
    const readable = String(title || 'websim-project').toLowerCase()
      .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 54) || 'project';
    const suffix = String(projectId || 'backup').replace(/[^a-z0-9]/gi, '').slice(-8).toLowerCase() || 'backup';
    return `websim-${readable}-${suffix}`.slice(0, 100);
  }

  function branchName(settings, repository) {
    if (settings.branchMode === 'default') return repository.default_branch || 'main';
    if (settings.branchMode === 'custom') {
      return String(settings.customBranch || 'main').trim()
        .replace(/[^a-zA-Z0-9._/-]/g, '-').replace(/^\/|\/$/g, '') || 'main';
    }
    return settings.branchMode || 'main';
  }

  async function findExistingRepository(owner, token, projectId, repoNames) {
    for (const repoName of repoNames) {
      try {
        const repository = await githubRequest(repoPath(owner, repoName), token);
        await debugLog('repository.resolve.found', {
          owner,
          repo: repository.name || repoName,
          source: repoName === repoNames[0] ? 'project-map' : 'generated-name',
          size: repository.size ?? null,
          defaultBranch: repository.default_branch || null
        });
        return repository;
      } catch (error) {
        if (!/not found/i.test(error.message)) throw error;
      }
    }

    for (let page = 1; page <= 10; page += 1) {
      const repositories = await githubRequest(`/user/repos?per_page=100&page=${page}&sort=updated`, token);
      const match = (Array.isArray(repositories) ? repositories : []).find((repository) => {
        const name = String(repository.name || '').toLowerCase();
        const projectSuffix = String(projectId || '').replace(/[^a-z0-9]/gi, '').slice(-8).toLowerCase();
        return repoNames.some((candidate) => name === String(candidate).toLowerCase()) ||
          (projectSuffix && name.endsWith(`-${projectSuffix}`) && name.startsWith('websim-')) ||
          String(repository.description || '').includes(String(projectId || ''));
      });
      if (match) {
        await debugLog('repository.resolve.found', {
          owner,
          repo: match.name,
          source: 'repository-list',
          size: match.size ?? null,
          defaultBranch: match.default_branch || null
        });
        return match;
      }
      if (!Array.isArray(repositories) || repositories.length < 100) break;
    }
    return null;
  }

  async function ensureRepository(payload, revision, settings) {
    await debugLog('repository.resolve.start', {
      projectId: payload.projectId,
      requestedName: generatedRepoName(payload.projectId, payload.title || revision.title)
    });
    const user = await githubRequest('/user', settings.token);
    const owner = user.login;
    const mapped = settings.projectMap?.[payload.projectId];
    const generatedName = generatedRepoName(payload.projectId, payload.title || revision.title);
    const repoNames = [...new Set([mapped?.repo, generatedName].filter(Boolean))];
    let repository = await findExistingRepository(owner, settings.token, payload.projectId, repoNames);
    let created = false;
    const repoName = generatedName;
    if (!repository) {
      repository = await githubRequest('/user/repos', settings.token, {
        method: 'POST',
        body: JSON.stringify({
          name: repoName,
          description: `Websim backup for ${payload.title || payload.projectId}`,
          private: settings.visibility !== 'public',
          auto_init: false
        }),
        headers: { 'Content-Type': 'application/json' }
      });
      created = true;
      await debugLog('repository.created', {
        owner,
        repo: repoName,
        visibility: settings.visibility === 'public' ? 'public' : 'private'
      });
    }
    const mappedRepository = mapped?.repo && String(repository.name || repoName).toLowerCase() === String(mapped.repo).toLowerCase();
    return {
      owner,
      repo: repository.name || repoName,
      branch: mappedRepository && mapped.branch ? mapped.branch : branchName(settings, repository),
      defaultBranch: repository.default_branch || 'main',
      empty: !repository.default_branch,
      created
    };
  }

  async function githubRequest(path, token, options = {}) {
    const method = options.method || 'GET';
    await debugLog('github.request', { method, path });
    try {
      const data = await jsonRequest(`${GH_API}${path}`, {
        ...options,
        headers: { Authorization: `Bearer ${token}`, 'X-GitHub-Api-Version': '2022-11-28', ...(options.headers || {}) }
      });
      await debugLog('github.response', { method, path, status: 200 });
      return data;
    } catch (error) {
      await debugLog('github.error', { method, path, status: error.status || null, message: error.message });
      throw error;
    }
  }

  async function commitToGithub(files, project, revision, settings, target) {
    const basePath = repoPath(target.owner, target.repo);
    const branch = encodeURIComponent(target.branch);
    await debugLog('git.bootstrap.start', {
      owner: target.owner,
      repo: target.repo,
      branch: target.branch,
      emptyRepository: Boolean(target.empty),
      fileCount: Object.keys(files).length
    });
    let parentSha = null;
    let branchExists = false;
    if (!target.empty) {
      try {
        const ref = await githubRequest(`${basePath}/git/ref/heads/${branch}`, settings.token);
        parentSha = ref.object?.sha || null;
        branchExists = Boolean(parentSha);
      } catch (error) {
        if (!/not found|empty/i.test(error.message) && error.status !== 409) throw error;
        if (target.branch !== target.defaultBranch) {
          try {
            const defaultRef = await githubRequest(`${basePath}/git/ref/heads/${encodeURIComponent(target.defaultBranch || 'main')}`, settings.token);
            parentSha = defaultRef.object?.sha || null;
          } catch (fallbackError) {
            if (!/not found|empty/i.test(fallbackError.message) && fallbackError.status !== 409) throw fallbackError;
          }
        }
      }
    }
    const parentCommit = parentSha ? await githubRequest(`${basePath}/git/commits/${parentSha}`, settings.token) : null;
    const blobEntries = await Promise.all(Object.entries(files).map(async ([path, bytes]) => ({
      path, mode: '100644', type: 'blob',
      sha: (await githubRequest(`${basePath}/git/blobs`, settings.token, {
        method: 'POST', body: JSON.stringify({ content: toBase64(bytes), encoding: 'base64' }),
        headers: { 'Content-Type': 'application/json' }
      })).sha
    })));
    const tree = await githubRequest(`${basePath}/git/trees`, settings.token, {
      method: 'POST', body: JSON.stringify({ base_tree: parentCommit?.tree?.sha, tree: blobEntries }),
      headers: { 'Content-Type': 'application/json' }
    });
    await debugLog('git.tree.created', {
      owner: target.owner,
      repo: target.repo,
      treeSha: tree.sha,
      parentSha: parentSha || null
    });
    const version = revision.version ?? revision.revision_number ?? project.version ?? '?';
    const title = String(project.title || revision.title || project.projectId || 'Websim project').replace(/[\r\n]+/g, ' ').slice(0, 120);
    const commit = await githubRequest(`${basePath}/git/commits`, settings.token, {
      method: 'POST',
      body: JSON.stringify({
        message: `v${version}: ${title}`,
        tree: tree.sha,
        ...(parentSha ? { parents: [parentSha] } : {})
      }),
      headers: { 'Content-Type': 'application/json' }
    });
    await debugLog('git.commit.created', {
      owner: target.owner,
      repo: target.repo,
      branch: target.branch,
      commitSha: commit.sha,
      parentSha: parentSha || null
    });
    if (parentSha) {
      if (branchExists) {
        await githubRequest(`${basePath}/git/refs/heads/${branch}`, settings.token, {
          method: 'PATCH', body: JSON.stringify({ sha: commit.sha, force: false }),
          headers: { 'Content-Type': 'application/json' }
        });
      } else {
        await githubRequest(`${basePath}/git/refs`, settings.token, {
          method: 'POST', body: JSON.stringify({ ref: `refs/heads/${target.branch}`, sha: commit.sha }),
          headers: { 'Content-Type': 'application/json' }
        });
      }
    } else {
      await githubRequest(`${basePath}/git/refs`, settings.token, {
        method: 'POST', body: JSON.stringify({ ref: `refs/heads/${target.branch}`, sha: commit.sha }),
        headers: { 'Content-Type': 'application/json' }
      });
    }
    await debugLog('git.branch.ready', {
      owner: target.owner,
      repo: target.repo,
      branch: target.branch,
      commitSha: commit.sha
    });
    return { sha: commit.sha, version, title, url: commit.html_url || `https://github.com/${target.owner}/${target.repo}/commit/${commit.sha}` };
  }

  async function remember(event, versionKey) {
    const stored = await config();
    const events = [event, ...(stored.lastEvents || [])].slice(0, 12);
    await storageSet({ lastEvents: events, syncedVersions: { ...(stored.syncedVersions || {}), [versionKey]: event.version } });
  }

  async function sync(payload, tabId) {
    const settings = await config();
    await debugLog('sync.request.received', { tabId: tabId || null, projectId: payload?.projectId || null, url: payload?.url ? String(payload.url).split(/[?#]/)[0] : null, title: payload?.title || null });
    if (!settings.enabled) {
      await debugLog('sync.blocked', { reason: 'auto-sync-disabled' });
      throw new Error('Auto-sync is paused in the extension popup');
    }
    if (!settings.token) {
      await debugLog('sync.blocked', { reason: 'github-token-missing' });
      throw new Error('Open the extension popup and finish GitHub setup');
    }
    let stage = 'resolve-project';
    await debugLog('sync.start', { projectId: payload?.projectId || null, url: payload?.url || null, title: payload?.title || null });
    let projectId = null;
    try {
      projectId = await resolveProjectId(payload);
      if (!projectId) throw new Error('Could not identify the pinned project');
      if (syncInFlight.has(projectId)) {
        await debugLog('sync.skipped-in-flight', { projectId });
        return { ok: true, inProgress: true, message: 'A sync for this project is already in progress' };
      }
      syncInFlight.add(projectId);
      stage = 'fetch-current-revision';
      const { version, revision } = await currentRevision(projectId);
      await debugLog('websim.revision.selected', { projectId, version });
      stage = 'resolve-or-create-repository';
      const target = await ensureRepository({ ...payload, projectId }, revision, settings);
      const versionKey = `${target.owner}/${target.repo}:${projectId}:${target.branch}`;
      if (String(settings.syncedVersions?.[versionKey]) === String(version)) {
        await debugLog('sync.skipped-duplicate', { projectId, version, owner: target.owner, repo: target.repo, branch: target.branch });
        return { ok: true, message: `v${version} is already in ${target.owner}/${target.repo}` };
      }
      stage = 'fetch-revision-files';
      const files = await revisionFiles(projectId, version, revision);
      stage = 'create-github-commit';
      const commit = await commitToGithub(files, { ...payload, projectId }, revision, settings, target);
      const stored = await config();
      await storageSet({
        owner: target.owner,
        projectMap: { ...(stored.projectMap || {}), [projectId]: { repo: target.repo, branch: target.branch } }
      });
      await remember({ title: commit.title, version: commit.version, projectId, repo: target.repo, branch: target.branch, sha: commit.sha, url: commit.url, at: Date.now() }, versionKey);
      await debugLog('sync.complete', { projectId, version, owner: target.owner, repo: target.repo, branch: target.branch, commitSha: commit.sha });
      return { ok: true, message: `${target.created ? 'Created repo and committed' : 'Committed'} v${commit.version} to ${target.owner}/${target.repo} · ${target.branch}`, commit };
    } catch (error) {
      await debugLog('sync.failed', { stage, status: error.status || null, message: error.message });
      throw error;
    } finally {
      if (projectId) syncInFlight.delete(projectId);
    }
  }

  async function triggerAutoSync(details, mutation, body, beforeState) {
    const tabId = Number.isInteger(details.tabId) && details.tabId >= 0 ? details.tabId : null;
    await debugLog('pin.candidate.response', { tabId, projectId: mutation.projectId, status: details.statusCode, body });
    if (details.statusCode < 200 || details.statusCode >= 300) return;
    await new Promise((resolve) => setTimeout(resolve, 350));
    const settings = await config();
    const afterState = await readProjectMutationState(mutation.projectId);
    if (!beforeState || !afterState) {
      await debugLog('pin.candidate.ignored', {
        projectId: mutation.projectId,
        reason: 'pin-state-unavailable'
      });
      return;
    }
    if (beforeState.version === afterState.version && beforeState.fingerprint === afterState.fingerprint) {
      await debugLog('pin.candidate.ignored', {
        projectId: mutation.projectId,
        reason: 'pin-state-unchanged',
        version: afterState.version
      });
      return;
    }
    if (afterState && knownSyncedVersion(settings, mutation.projectId) !== null &&
      String(knownSyncedVersion(settings, mutation.projectId)) === String(afterState.version)) {
      await debugLog('pin.candidate.ignored', {
        projectId: mutation.projectId,
        reason: 'version-already-synced',
        version: afterState.version
      });
      return;
    }
    let tab = null;
    if (tabId !== null) {
      try { tab = await api.tabs.get(tabId); } catch {}
    }
    const payload = { projectId: mutation.projectId, url: tab?.url || details.documentUrl || `https://websim.com/p/${mutation.projectId}`, title: null };
    await debugLog('pin.autosync.trigger', { tabId, ...payload });
    setSyncIndicator(true);
    if (tabId !== null) api.tabs.sendMessage(tabId, { type: 'SYNC_STARTED', source: 'project-patch' }).catch(() => {});
    sync(payload, tabId).then((result) => { notify(tabId, result); }).catch((error) => {
      const result = { ok: false, message: error.message };
      notify(tabId, result);
    });
  }

  async function notify(tabId, result) {
    if (!result.inProgress) setSyncIndicator(false);
    if (Number.isInteger(tabId) && tabId >= 0) api.tabs.sendMessage(tabId, { type: 'SYNC_RESULT', ...result }).catch(() => {});
    if (result.ok && api.notifications) {
      api.notifications.create(`pin-${Date.now()}`, { type: 'basic', title: 'Pin to GitHub', message: result.message, iconUrl: api.runtime.getURL('icon-128.png') }).catch(() => {});
    }
  }

  async function projectLink(payload) {
    const settings = await config();
    if (!settings.token) return { ok: true, status: 'not-configured' };
    const projectId = await resolveProjectId(payload);
    if (!projectId) return { ok: true, status: 'not-websim' };
    const mapped = settings.projectMap?.[projectId];
    const user = await githubRequest('/user', settings.token);
    const generatedName = generatedRepoName(projectId, payload?.title);
    const names = [...new Set([mapped?.repo, generatedName].filter(Boolean))];
    const repository = await findExistingRepository(user.login, settings.token, projectId, names);
    const repo = repository?.name || generatedName;
    const mappedRepository = mapped?.repo && repo.toLowerCase() === String(mapped.repo).toLowerCase();
    const branch = mappedRepository && mapped.branch ? mapped.branch : branchName(settings, repository || {});
    await debugLog('repository.link.preview', { projectId, owner: user.login, repo, branch, status: repository ? 'linked' : 'planned' });
    return { ok: true, status: repository ? 'linked' : 'planned', projectId, owner: user.login, repo, branch, url: `https://github.com/${user.login}/${repo}` };
  }

  if (api.webRequest?.onBeforeRequest) {
    const requestFilter = { urls: ['https://websim.com/*', 'https://*.websim.com/*'] };
    try {
      api.webRequest.onBeforeRequest.addListener((details) => {
        const url = websimNetworkUrl(details.url);
        if (!url) return;
        const mutation = details.method === 'PATCH' ? projectMutation(details.url) : null;
        const body = requestBodySummary(details.requestBody);
        if (mutation) {
          const beforeState = readProjectMutationState(mutation.projectId);
          trackedWebsimRequests.set(details.requestId, { mutation, body, beforeState, tabId: details.tabId });
          debugLog('pin.candidate.request', { tabId: details.tabId, projectId: mutation.projectId, method: details.method, body });
        }
        config().then((state) => state.advancedLogs && debugLog('network.request', {
          requestId: details.requestId,
          method: details.method,
          type: details.type,
          url,
          ...(mutation ? { projectId: mutation.projectId, body } : {})
        }));
      }, requestFilter, ['requestBody']);
      api.webRequest.onCompleted?.addListener((details) => {
        const url = websimNetworkUrl(details.url);
        if (!url) return;
        const tracked = trackedWebsimRequests.get(details.requestId);
        if (tracked) {
          trackedWebsimRequests.delete(details.requestId);
          Promise.resolve(tracked.beforeState).then((beforeState) =>
            triggerAutoSync(details, tracked.mutation, tracked.body, beforeState)
          ).catch((error) => {
            debugLog('pin.autosync.failed', { tabId: details.tabId, projectId: tracked.mutation.projectId, message: error.message });
          });
        }
        config().then((state) => state.advancedLogs && debugLog('network.response', {
          requestId: details.requestId,
          status: details.statusCode,
          type: details.type,
          url
        }));
      }, requestFilter);
      api.webRequest.onErrorOccurred?.addListener((details) => {
        const url = websimNetworkUrl(details.url);
        if (!url) return;
        const tracked = trackedWebsimRequests.get(details.requestId);
        if (tracked) {
          trackedWebsimRequests.delete(details.requestId);
          debugLog('pin.candidate.failed', { tabId: details.tabId, projectId: tracked.mutation.projectId, error: details.error, body: tracked.body });
        }
        config().then((state) => state.advancedLogs && debugLog('network.error', {
          requestId: details.requestId,
          error: details.error,
          type: details.type,
          url
        }));
      }, requestFilter);
      debugLog('network.monitor.ready', { watches: ['PATCH /api/v1/projects/{id}', 'Websim API requests'] });
    } catch (error) {
      debugLog('network.monitor.unavailable', { message: error.message });
    }
  }

  api.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'GET_STATE') {
      config().then((stored) => sendResponse({ ...stored, token: '', hasToken: Boolean(stored.token) }));
      return true;
    }
    if (message?.type === 'GET_LOGS') {
      config().then((stored) => sendResponse({ logs: stored.debugLogs || [] }));
      return true;
    }
    if (message?.type === 'GET_PROJECT_LINK') {
      projectLink(message).then(sendResponse).catch((error) => sendResponse({ ok: false, message: error.message }));
      return true;
    }
    if (message?.type === 'CLEAR_LOGS') {
      storageSet({ debugLogs: [] }).then(() => sendResponse({ ok: true }));
      return true;
    }
    if (message?.type === 'SET_DEBUG_MODE') {
      storageSet({ advancedLogs: Boolean(message.enabled) }).then(() => sendResponse({ ok: true, advancedLogs: Boolean(message.enabled) }));
      return true;
    }
    if (message?.type === 'DEBUG_EVENT') {
      config().then((stored) => {
        if (!stored.advancedLogs) return sendResponse({ ok: true, recorded: false });
        debugLog(message.event || 'content.debug', safeDebugDetail(message.detail)).then(() => sendResponse({ ok: true, recorded: true }));
      });
      return true;
    }
    if (message?.type === 'SAVE_SETTINGS') {
      config().then((stored) => storageSet({
        ...stored,
        ...message.settings,
        token: message.settings.token || stored.token
      })).then(async () => {
        const saved = await config();
        let owner = saved.owner || '';
        if (saved.token) {
          const user = await githubRequest('/user', saved.token);
          owner = user.login;
          await storageSet({ owner });
        }
        sendResponse({ ok: true, owner });
      }).catch((error) => sendResponse({ ok: false, message: error.message }));
      return true;
    }
    if (message?.type === 'PIN_DETECTED') {
      debugLog('pin.message.received', { tabId: sender.tab?.id || null, senderUrl: sender.url ? String(sender.url).split(/[?#]/)[0] : null, payload: safeDebugDetail(message.payload || {}) });
      setSyncIndicator(true);
      sync(message.payload, sender.tab?.id).then((result) => { notify(sender.tab?.id, result); sendResponse(result); })
        .catch((error) => { const result = { ok: false, message: error.message }; notify(sender.tab?.id, result); sendResponse(result); });
      return true;
    }
    if (message?.type === 'SYNC_CURRENT') {
      const tabId = message.tabId;
      const url = message.url || '';
      const projectId = url.match(/\/(?:c|p)\/([a-zA-Z0-9_-]+)/)?.[1] || url.match(/^https:\/\/([a-zA-Z0-9_-]+)\.c\.websim\.com/)?.[1];
      setSyncIndicator(true);
      sync({ projectId, url, title: message.title }, tabId).then((result) => { notify(tabId, result); sendResponse(result); })
        .catch((error) => { const result = { ok: false, message: error.message }; notify(tabId, result); sendResponse(result); });
      return true;
    }
  });

  api.runtime.onInstalled.addListener(() => storageGet(defaults).then((stored) => storageSet({ ...defaults, ...stored })));
})();
